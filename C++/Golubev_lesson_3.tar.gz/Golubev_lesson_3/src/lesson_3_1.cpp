#include "_geek.h"

using _geek::print_hello;

int main()
{
   print_hello();
}