#include <iostream>

int main()
{
   size_t qty_sticks;
   std::cout << "Enter qty sticks from 10 to 30" << std::endl;
   std::cin >> qty_sticks;
   if (qty_sticks >= 10 and qty_sticks <= 30) {
      for (int i = qty_sticks; i > 0; i--)
      std::cout << "|";
      std::cout << std::endl;
      while (qty_sticks) {
         int q;
         std::cin >> q;
         qty_sticks -= q;
         for (int i = qty_sticks; i > 0; i--) {
               std::cout << "|";
         }
         std::cout << std::endl;
      }
   std::cout << "You've just lost" << std::endl;
   } else 
      std::cout << "Try again" << std::endl;

}