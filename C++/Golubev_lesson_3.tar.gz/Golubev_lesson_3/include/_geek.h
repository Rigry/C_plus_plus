#include <iostream>
namespace _geek {

   void print_hello()
   {
      std::cout << "Hello, World!" << std::endl;
   }
}