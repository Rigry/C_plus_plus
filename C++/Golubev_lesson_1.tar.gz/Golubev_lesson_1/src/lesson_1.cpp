#include <iostream>
#include "include.h"

int main()
{
   std::cout << "Sample string \t Sample string 2" << std::endl;
   std::cout << STRING_1 ENTER TAB   STRING_2 << std::endl;
   std::cout << STRING_1 ENTER RESET STRING_2 << std::endl;
   std::cout << STRING_1 TAB   RESET STRING_2 << std::endl;
}